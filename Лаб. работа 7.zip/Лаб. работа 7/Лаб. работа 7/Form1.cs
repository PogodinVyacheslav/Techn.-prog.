﻿using System.Windows.Forms;
using Лаб.работа_7.Controllers;

namespace Лаб.работа_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MapController.Init(this);
        }
    }
}
