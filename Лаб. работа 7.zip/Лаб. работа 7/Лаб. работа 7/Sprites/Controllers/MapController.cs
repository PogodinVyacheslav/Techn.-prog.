﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаб.работа_7.Controllers
{
    public static class MapController
    {
        public const int mapSize = 8;
        public const int cellSize = 50;

        public static int[,] map = new int[mapSize, mapSize];

        public static Button[,] buttons = new Button[mapSize, mapSize];

        public static Image spriteSet;

        private static void ConfigureMapSize()
        {
            current.Width = mapSize * cellSize + 20;
            current.Height = (mapSize + 1) * cellSize;
        }
        private static void InitMap(Form current)
        {
            for (int i = 0; i < mapSize; i++)
            {
                for (int j = 0; j < mapSize; j++)
                {
                    map[i, j] = 0;
                }
            }
        }

        public static void Init(Form current)
        {
            spriteSet = new Bitmap(Path.Combine(new DirectoryInfo(Directory.GetCurrentDirectory()).Parent.Parent.FullName.ToString(), "Sprites\\Dwarf.png"));
            ConfigureMapSize(current);
            InitMap();
            InitButtons(current);
        }

        private static void InitButtons(Form current)
        {
            for (int i = 0; i < mapSize; i++)
            {
                for (int j = 0; j < mapSize; j++)
                {
                    Button button = new Button();
                    button.Location = new Point(j * cellSize, i * cellSize);
                    button.Size = new Size(cellSize, cellSize);
                    current.Controls.Add(button);
                    buttons[i, j] = button;
                }
            }
        }

        public static Image FindNeededImage(int xPos,int yPos)
        {
            Image image = new Bitmap(cellSize, cellSize);
            Graphics g =Graphics.FromImage(image);
            g.DrawImage(spriteSet,new Rectangle(new Point(0,0),new Size(cellSize,cellSize)),0+32*xPos,0+23*yPos,33,33,GraphicsUnit.Pixel);
            return null;
        }
    }
}
