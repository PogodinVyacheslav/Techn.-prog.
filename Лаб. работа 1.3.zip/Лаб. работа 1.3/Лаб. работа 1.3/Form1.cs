﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace Лаб.работа_1._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class Color
        {
            public string a = "Red";
            public string b = "Blue";
            public const bool c = true;
            public const bool d = false;
            public ulong[] arr1 = { 1, 2, 3 };
            public ulong[] arr2 = { 4, 5, 6 };

            public enum Numbers: uint
            {
                a = 111, b = 222, c = 333
            }

            private void Form1_Load(object sender, EventArgs e)
            {
                a = "Green";
                b = "Yellow";
            }

        }
    }
}
