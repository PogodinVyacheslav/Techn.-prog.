﻿using System.Text.RegularExpressions;


string p1=Path.Combine("C:\\Users\\vaceslav\\source\\repos\\Техн. прог\\Лаб. работа 4\\ОБУЧЕНИЕ");
string p2=Path.Combine("C:\\Users\\vaceslav\\source\\repos\\Техн. прог\\Лаб. работа 4\\ОБУЧЕНИЕ\\IT.txt");
string p3=Path.Combine("C:\\Users\\vaceslav\\source\\repos\\Техн. прог\\Лаб. работа 4\\ОБУЧЕНИЕ\\ВУЗ.jpg");
 
string pat1=@"\b[I]\w+";
string pat2=@"\b[В]\w+";
Regex rg1=new Regex(pat1);
Regex rg2=new Regex(pat2);

string ps=p1+p2+p3;

MatchCollection m1ps=rg1.Matches(ps);
MatchCollection m2ps=rg2.Matches(ps);

for (int i=0; i<m1ps.Count; i++)
    Console.WriteLine("1 группа - " + m1ps[i].Value + ";\n");

for (int j=0; j<m2ps.Count; j++)
    Console.WriteLine("2 группа - " + m2ps[j].Value + ";\n");


string p4=Path.Combine(p1+"\\ВУЗ\\ВУЗ.jpg"+";\n");
Console.WriteLine(p4);

string p5 = Path.Combine(p1+"\\TMP\\IT.txt"+";\n");
Console.WriteLine(p5);
