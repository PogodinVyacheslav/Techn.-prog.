﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;

namespace Лаб.работа_6
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load+=new EventHandler(Form1_Load);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public int x1;
        public int x2;
        public int y1;
        public int y2;
        public int kx;
        public int kg;
        public double r;

        private void err(string n, double x, double y, string E)
        {
            string p=textBox1.Text+"\\myErrors.log";
            FileStream F=new FileStream(p,FileMode.Create);
            F.Seek(0,SeekOrigin.End);
            StreamWriter s=new StreamWriter(F);
            s.WriteLine("Файл: {0}",n);
            s.WriteLine("Функция: y*2^(ln(x-1))");
            s.WriteLine("X: {0}; Y: {1};",x,y);
            s.WriteLine("Ошибка: {0}",E);
        }

        private void prog()
        {
            string p=textBox1.Text+"\\myProgram.log";
            FileStream F=new FileStream(p,FileMode.Create);
            F.Seek(0,SeekOrigin.End);
            StreamWriter s=new StreamWriter(F);
            s.WriteLine("Программа: лаб. работа 6, вариант: 28");
            s.WriteLine("Дата и время расчёта:");
            s.WriteLine(DateTime.Now);
            s.WriteLine("Функция: y*2^(ln(x-1))");
            s.WriteLine("Файлы с результатами расчётов по наборам данных:");
            for(int i=0; i<kg; i++)
            {
                s.Write("G{0} ",i.ToString());
            }
            s.Close();
            F.Close();
        }

        private void dat(int h)
        {
            string P=textBox1.Text;
            string C=h.ToString();
            P+=string.Format("\\G{0}.rez",C);
            try
            {
                FileStream fs=new FileStream(P,FileMode.Open,FileAccess.Read);
                StreamReader sr=new StreamReader(fs);
                string str;
                List<string> ls=new List<string>();
                while((str=sr.ReadLine())!=null)
                {
                    ls.Add(str);
                }
                x1=Convert.ToInt32(textBox6.Text);
                x2=Convert.ToInt32(textBox8.Text);
                y1=Convert.ToInt32(textBox7.Text);
                y2=Convert.ToInt32(textBox9.Text);
                string[] L=ls.ToArray();
                string[,] m=new string[x2+3,y2+3];
                for(int i=3+y1; i<=2+y2; i++)
                {
                    Console.WriteLine(L[i]);
                    string t=L[i].ToString();
                    string[] T=t.Split(' ');
                    string[] text=T.ToArray();
                    string it="";
                    text=text.Where(x=>x != it).ToArray();
                    for(int j=1+x1; j<=x2; j++)
                    {
                        m[i,j]=text[j];
                        Console.WriteLine(text[j]);
                        richTextBox1.AppendText(Convert.ToString(m[i,j])+"  ");
                    }
                    richTextBox1.AppendText(Convert.ToString('\n'));
                }
                richTextBox1.AppendText(Convert.ToString('\n'));
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void G(double[]X, double[]Y, int h)
        {
            int cy=0;
            int c1=1;
            int cx=0;
            string P=textBox1.Text;
            string C=h.ToString();
            P+=string.Format("\\G{0}.rez",C);
            Console.WriteLine(P);
            try
            {
                FileStream fl=new FileStream(P,FileMode.Create);
                fl.Seek(0,SeekOrigin.End);
                StreamWriter s=new StreamWriter(fl);
                s.WriteLine("Функция: y*2^(ln(x-1))");
                s.Write("X: {0}; Y: {1}\n",X.Length,Y.Length);
                s.Write("Y / X  ");
                for(int k=0; k<X.Length; k++)
                {
                    s.Write("x{0}       ",k);
                }
                s.WriteLine();

                for(int i=0; i<Y.Length; i++)
                {
                    cy=0;
                    for(int j=0; j<X.Length; j++)
                    {
                        try
                        {
                            r=Y[i]*Math.Pow(2,Math.Log(X[j]-1));
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                            err(("G{0}",C).ToString(),X[i],Y[j],ex.Message);
                            Application.Exit();
                        }
                        listBox1.Items.Add(r);
                        cy++;
                        if(c1==1)
                        {
                            s.Write("y{0},   ",cx);
                            cx++;
                            c1=0;
                        }
                        s.Write("{0,6:f4}  ",r);
                        if(cy==Y.Length)
                        {
                            s.WriteLine();
                        }
                    }
                    c1=1;
                }
                s.Write("Данные x:\n");
                for(int k=0; k<X.Length; k++)
                {
                    s.Write(string.Format("{0}; ",Convert.ToString(X[k])));
                }
                s.Write('\n');
                s.Write("Данные y:\n");
                for(int k=0; k<Y.Length; k++)
                {
                    s.Write(string.Format("{0}; ",Convert.ToString(Y[k])));
                }
                s.WriteLine();
                s.WriteLine();
                s.Close();
                fl.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random R=new Random();
            int kl;
            kx=Convert.ToInt32(textBox3.Text);
            double hx=Convert.ToInt32(textBox4.Text);
            double x0=Convert.ToInt32(textBox5.Text);
            double x=x0;
            double[]X=new double[kx];
            double[]Y=new double[kx];
            int M=1;
            int c=0;
            kl=Convert.ToInt32(textBox2.Text);
            for(int j=0; j<kl; j++)
            {
                for(int i=0; i<kx; i++)
                {
                    if(c==0)
                    {
                        x=R.Next(10,100);
                        X[i]=x;
                        c++;
                    }
                    else
                    {
                        X[i]=x;
                    }
                    x+=hx;
                }

                for(int i=0; i<kx; i++)
                {
                    Y[i]=R.Next(10,100);
                }
                Array.Sort(Y);

                G(X, Y, M);
                kg++;
                dat(M);
                M++;
            }
            prog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog D = new FolderBrowserDialog();
            D.ShowDialog();
            if(D.ShowDialog()==DialogResult.OK)
            {
                textBox1.Text=D.SelectedPath;
            }
        }
    }
}
