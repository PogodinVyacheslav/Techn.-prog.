﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаб.работа_1._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_MouseHover(object sender, EventArgs e)
        {
            linkLabel1.Text = "Ссылка";
        }

        private void linkLabel1_MouseLeave(object sender, EventArgs e)
        {
            linkLabel1.Text = "linkLabel1";
        }

        private void linkLabel1_MouseClick(object sender, MouseEventArgs e)
        {
            linkLabel1.BackColor = Color.Yellow;
            int i = 0;
                if(i == 0)
                i += 1;
        }

        private void splitContainer1_Panel1_MouseClick(object sender, MouseEventArgs e)
        {
            splitContainer1.BackColor = Color.Blue;
            int j = 0;
                if(j == 0)
                j -= 1;
        }

        private void splitContainer1_Panel2_MouseClick(object sender, MouseEventArgs e)
        {
            splitContainer1.BackColor = Color.Red;
        }

        private void splitContainer1_Panel1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            splitContainer1.BackColor = Color.Purple;
        }

        private void splitContainer1_Panel2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            splitContainer1.BackColor = Color.Purple;
        }

        private void dataGridView1_MouseHover(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.Black;
        }

        private void dataGridView1_MouseLeave(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.Gray;
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            dataGridView1.BackgroundColor = Color.White;
        }

    }
}
