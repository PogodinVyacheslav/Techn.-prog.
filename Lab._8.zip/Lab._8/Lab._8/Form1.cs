﻿using System;
using System.Windows.Forms;

namespace Lab._8
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender,EventArgs e)
        {
            try
            {
                int N=vScrollBar1.Value;
                int M=hScrollBar1.Value;
                double k=Convert.ToDouble(textBox1.Text);
                if(k<-5.5||k>4.5)
                {
                    MessageBox.Show("Не соот. диап.");
                    Application.Exit();
                }
                double[,] A=new double[N,M];

                for(int i=0; i<N; i++)
                {
                    for(int j=0; j<M; j++)
                    {
                        if(i==j)
                        {
                            A[i,j]=0;
                        }
                        else
                        {
                            A[i,j]=k*Math.Pow(-1,i+j)+j/10.0;
                        }
                    }
                }

                Form f=new Form();
                DataGridView dgv=new DataGridView();
                dgv.Dock=DockStyle.Fill;
                f.Controls.Add(dgv);
                for(int j=0; j<M; j++)
                {
                    dgv.Columns.Add("col"+j,"Столб. "+(j+1));
                }

                for(int i=0; i<N; i++)
                {
                    dgv.Rows.Add();
                    for(int j=0; j<M; j++)
                    {
                        if((checkBox1.Checked==true && A[i,j]>0)||
                           (checkBox2.Checked==true && A[i,j]<0)||
                           (checkBox3.Checked==true && A[i,j]==0)||
                           (checkBox4.Checked==true && A[i,j]==double.NaN))
                            {
                            if(A[i,j]==double.NaN)
                            {
                                A[i,j]=0;
                            }
                            dgv.Rows[i].Cells[j].Value=A[i,j];
                        }
                        else
                        {
                            A[i,j]=double.NaN;
                        }
                    }
                }
                f.ShowDialog();
            }
            catch{}
        }
    }
}
