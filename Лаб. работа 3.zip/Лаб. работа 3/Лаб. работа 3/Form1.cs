﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Лаб.работа_3
{
    public partial class Form1:Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private double f(double A)
        {
            double F4=0;
            for (int j=0; j<=1000000; j++)
            {
                F4+=1/(A+Math.Sqrt(j));
            }
            return F4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int A=Convert.ToInt32(textBox1.Text.Replace(".",","));
            int B=Convert.ToInt32(textBox2.Text.Replace(".",","));
            int C=Convert.ToInt32(textBox3.Text.Replace(".",","));
            int D=(int)((B-A)/C);

            if (D<999)
            {
                MessageBox.Show("Маленький диапазон");
                Environment.Exit(1);
            }
            
            int[] R = Enumerable.Range(A,B-1).ToArray();
            foreach (int i in R)
            {
                try
                {
                    double F1=Math.Atan(A);
                    double F2=Math.Exp(-Math.Pow(0.1,A));
                    double A1=Math.Atan(-Math.Pow(A,2));
                    double A2=Math.Abs(A);
                    double F3=Math.Log(A1,A2);
                    double F4=f(A);

                    if (A2==1 || A2<=0 || A1<=0)
                    {
                        MessageBox.Show("Несущ. значение");
                        Environment.Exit(1);
                    }
                    else
                    {
                        string F=Convert.ToString(Math.Round(F1+F2+F3+F4,3));
                        listBox1.Items.Add(F);
                        A+=C;
                    }

                }
                catch(DivideByZeroException)
                {
                    MessageBox.Show("Деление на ноль");
                    Environment.Exit(1);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

    }
}
