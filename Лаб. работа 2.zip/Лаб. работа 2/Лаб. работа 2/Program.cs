﻿using System.Reflection;

public class TrCalc
{
    private readonly double _tc;
    private readonly double _t;
    private readonly string _e;

    public TrCalc(double t, double tc, string e)
    {
        _t = t;
        _tc = tc;
        _e = e;
    }

    public string T {get {return $"{_t}°C";}}
    public string Tc {get {return $"{_tc}°K";}}
    public string Tr {get {return $"{Math.Round(_t/_tc,3)}°C/°K";}}

    public override string ToString()
    {
        return $"{_e}, при {nameof(T)} = {T} и {nameof(Tc)} = {Tc}, {nameof(Tr)} = {Tr}, Дата изменения - {DateTime.Now}";
    }
}
internal class Program
{
    static void Main(string[] args)
    {
        for (double i = 100; i <= 200; i += 2.5)
        {
            Console.WriteLine(new TrCalc(i, 132.9, "CO").ToString());
            Console.WriteLine(new TrCalc(i, 304.2, "CO2").ToString());
            Console.WriteLine(new TrCalc(i, 190.6, "СН4").ToString());
            Console.WriteLine();
        }

        Console.ReadKey();

    }
}

